// Initialize Swiper
const swiper = new Swiper(".mySwiper", {
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev"
  },
  loop: false
});

const addTextBtn = document.getElementById("addTextBtn");
const fontFamilySelect = document.getElementById("fontFamily");
const fontSizeInput = document.getElementById("fontSize");
const fontColorInput = document.getElementById("fontColor");

let selectedText = null;

// Add new text to current slide
addTextBtn.addEventListener("click", () => {
  const activeSlide = swiper.slides[swiper.activeIndex];
  const imageContainer = activeSlide.querySelector(".image-container");

  const newText = document.createElement("div");
  newText.classList.add("text-box");
  newText.contentEditable = true;
  newText.innerText = "Edit me";

  // Random position (within image)
  newText.style.top = "50%";
  newText.style.left = "30%";

  // Apply default styles
  newText.style.fontFamily = fontFamilySelect.value;
  newText.style.fontSize = fontSizeInput.value + "px";
  newText.style.color = fontColorInput.value;

  imageContainer.appendChild(newText);

  // Add event listeners
  makeDraggable(newText);
  newText.addEventListener("click", (e) => {
    e.stopPropagation();
    selectTextBox(newText);
  });

  selectTextBox(newText);
});

// Select a text box
function selectTextBox(el) {
  if (selectedText) selectedText.classList.remove("selected");
  selectedText = el;
  el.classList.add("selected");
  fontFamilySelect.value = getComputedStyle(el).fontFamily.replace(/['"]/g, '');
  fontSizeInput.value = parseInt(getComputedStyle(el).fontSize);
  fontColorInput.value = rgbToHex(getComputedStyle(el).color);
}

// Change font settings
fontFamilySelect.addEventListener("change", () => {
  if (selectedText) selectedText.style.fontFamily = fontFamilySelect.value;
});

fontSizeInput.addEventListener("input", () => {
  if (selectedText) selectedText.style.fontSize = fontSizeInput.value + "px";
});

fontColorInput.addEventListener("input", () => {
  if (selectedText) selectedText.style.color = fontColorInput.value;
});

// Deselect text when clicking outside
document.body.addEventListener("click", () => {
  if (selectedText) selectedText.classList.remove("selected");
  selectedText = null;
});

// Draggable function (bounded inside image)
function makeDraggable(el) {
  let offsetX, offsetY;

  el.addEventListener("mousedown", (e) => {
    e.preventDefault();
    offsetX = e.clientX - el.getBoundingClientRect().left;
    offsetY = e.clientY - el.getBoundingClientRect().top;

    function onMouseMove(e) {
      const parent = el.parentElement.getBoundingClientRect();
      let newLeft = e.clientX - parent.left - offsetX;
      let newTop = e.clientY - parent.top - offsetY;

      // Boundaries
      newLeft = Math.max(0, Math.min(newLeft, parent.width - el.offsetWidth));
      newTop = Math.max(0, Math.min(newTop, parent.height - el.offsetHeight));

      el.style.left = newLeft + "px";
      el.style.top = newTop + "px";
    }

    function onMouseUp() {
      document.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("mouseup", onMouseUp);
    }

    document.addEventListener("mousemove", onMouseMove);
    document.addEventListener("mouseup", onMouseUp);
  });
}

// Helper to convert RGB → HEX
function rgbToHex(rgb) {
  const result = rgb.match(/\d+/g);
  return result
    ? "#" +
        result
          .slice(0, 3)
          .map((x) => parseInt(x).toString(16).padStart(2, "0"))
          .join("")
    : "#000000";
}
